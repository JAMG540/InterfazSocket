package sockets;

public class ServidorMain 
{
    public static void main(String[] args) 
    {
		InterfazServidor servidor = new InterfazServidor();
		servidor.setVisible(true);
    }   
}