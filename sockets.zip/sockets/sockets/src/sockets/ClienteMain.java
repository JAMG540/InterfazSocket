
package sockets;


public class ClienteMain 
{
    public static void main(String[] args) 
    {
		InterfazClient cliente = new InterfazClient();
		cliente.setVisible(true);
    }   
}
