package sockets;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class InterfazServidor extends JFrame {

    private static final long serialVersionUID = 1583724102189855698L;

    JTextField PantallaPuerto;
    JLabel instruccionPuerto;
    JPanel panelInstrucciones, panelOperaciones;

    public InterfazServidor() 
    {
        super();
        setSize(600, 600);
        setTitle("Servidor del socket");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(true);

        // Elementos del panel
        JPanel panel = (JPanel) this.getContentPane();
        panel.setLayout(new GridLayout(4, 1));
        
        instruccionPuerto = new JLabel("Ingresa el puerto del receptor");
        instruccionPuerto.setVisible(true);

        panel.add("North", instruccionPuerto);

        PantallaPuerto = new JTextField("");
        PantallaPuerto.setFont(new Font("Arial", Font.BOLD, 25));
        PantallaPuerto.setHorizontalAlignment(JTextField.RIGHT);
        PantallaPuerto.setEditable(true);
        PantallaPuerto.setBackground(Color.WHITE);
        panel.add("North", PantallaPuerto);

        panelInstrucciones = new JPanel();
        panelInstrucciones.setLayout(new GridLayout(4, 3));
        panelInstrucciones.setBorder(new EmptyBorder(4, 4, 4, 4));

        panel.add("Center", panelInstrucciones);

        panelOperaciones = new JPanel();
        panelOperaciones.setLayout(new GridLayout(6, 1));
        panelOperaciones.setBorder(new EmptyBorder(4, 4, 4, 4));

        acciones("Guardar");
        panel.add("East", panelOperaciones);

        validate();
    }

    private void acciones(String operacion) {
        JButton btn = new JButton(operacion);
        btn.setForeground(Color.BLUE);

        btn.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseReleased(MouseEvent evt) {
                JButton btn = (JButton) evt.getSource();
                operacionPulsado(btn.getText());
            }
        });

        panelOperaciones.add(btn);
    }

    private void operacionPulsado(String tecla) {

        if (tecla.equals("Guardar")) {
            if (PantallaPuerto.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Ingresa el puerto receptor");

            } else {
                
                Vector<String> datosRecibidos = new Vector<String>();

                try {
                    ServerSocket s= new ServerSocket(Integer.parseInt(PantallaPuerto.getText()));
                    JOptionPane.showMessageDialog(null,"Esperando conexion");

                    while (true) {
                        Socket cliente = s.accept();
                        BufferedReader entrada = new BufferedReader(
                                new InputStreamReader(cliente.getInputStream()));
                        PrintWriter salida = new PrintWriter(
                                new OutputStreamWriter(cliente.getOutputStream()), true);
                        String datos = entrada.readLine();
                        if (datos.equals("DATOS")) {
                            for (int n = 0; n < datosRecibidos.size(); n++) {
                                salida.println(datosRecibidos.get(n));
                            }
                        } else {
                            datosRecibidos.add(0, datos);
                            salida.println("OK");
                        }
                        cliente.close();
                    }
                } catch (IOException e) {
                    System.out.println(e);
                }

            }

        }
    }

}
