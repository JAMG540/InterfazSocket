package sockets;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class InterfazClient extends JFrame {

    private static final long serialVersionUID = 1583724102189855698L;

    JTextField PantallaIP;
    JTextField PantallaPuerto;

    JLabel instruccionPuerto;
    JLabel instruccionIP;

    double resultado;

    String operacion;

    JPanel panelInstrucciones, panelOperaciones;

    boolean nuevaOperacion = true;

    public InterfazClient() {
        super();
        setSize(600, 600);
        setTitle("Cliente del socket");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(true);

        // Elementos del panel
        JPanel panel = (JPanel) this.getContentPane();
        panel.setLayout(new GridLayout(4, 1));

        instruccionIP = new JLabel("Ingresa la dirección ip del receptor");
        instruccionIP.setVisible(true);
        instruccionPuerto = new JLabel("Ingresa el puerto del receptor");
        instruccionPuerto.setVisible(true);

        panel.add("North", instruccionIP);

        PantallaIP = new JTextField("");
        PantallaIP.setFont(new Font("Arial", Font.BOLD, 25));
        PantallaIP.setHorizontalAlignment(JTextField.RIGHT);
        PantallaIP.setEditable(true);
        PantallaIP.setBackground(Color.WHITE);
        panel.add("North", PantallaIP);

        panel.add("North", instruccionPuerto);

        PantallaPuerto = new JTextField("");
        PantallaPuerto.setFont(new Font("Arial", Font.BOLD, 25));
        PantallaPuerto.setHorizontalAlignment(JTextField.RIGHT);
        PantallaPuerto.setEditable(true);
        PantallaPuerto.setBackground(Color.WHITE);
        panel.add("North", PantallaPuerto);

        panelInstrucciones = new JPanel();
        panelInstrucciones.setLayout(new GridLayout(4, 3));
        panelInstrucciones.setBorder(new EmptyBorder(4, 4, 4, 4));

        panel.add("Center", panelInstrucciones);

        panelOperaciones = new JPanel();
        panelOperaciones.setLayout(new GridLayout(6, 1));
        panelOperaciones.setBorder(new EmptyBorder(4, 4, 4, 4));

        acciones("Guardar");
        panel.add("East", panelOperaciones);

        validate();
    }

    private void acciones(String operacion) {
        JButton btn = new JButton(operacion);
        btn.setForeground(Color.BLUE);

        btn.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseReleased(MouseEvent evt) {
                JButton btn = (JButton) evt.getSource();
                operacionPulsado(btn.getText());
            }
        });

        panelOperaciones.add(btn);
    }

    private void operacionPulsado(String tecla) {

        if (tecla.equals("Guardar")) {
            if (PantallaIP.getText().equals("") || PantallaPuerto.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Llena ambos campos,por favor.");

            } else {
                // para conectarns desde otros equipos hay que agregar cambiar 
               // localhost por la ip del servidor
                
                String ip = "127.0.0.1";
                int puerto = 1237;
                System.out.println(" socket " + ip + " " + puerto);
                try {
                    Socket sk = new Socket(PantallaIP.getText(),Integer.parseInt(PantallaPuerto.getText()));
                    BufferedReader entrada = new BufferedReader(
                            new InputStreamReader(sk.getInputStream()));
                    PrintWriter salida = new PrintWriter(
                            new OutputStreamWriter(sk.getOutputStream()), true);
                    System.out.println("enviando...");
                    salida.println("Nombre usuario: " + " " + "Datos");
                    
                    JOptionPane.showMessageDialog(null, entrada.readLine());
                    
                    sk.close();
                } catch (Exception e) {
                    System.out.println("error: " + e.toString());
                }

            }

        }
    }

}
